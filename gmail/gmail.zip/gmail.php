<?php
session_start();

define('CLIENT_ID', '535144762860-n5g9b0oan6ar67mvatdg5bgq9ccbojna.apps.googleusercontent.com');
define('CLIENT_SECRET', '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');
define('REDIRECT_URI', 'https://nexis365.com/saas/gmail/gmail.php');
define('TOKEN_FILE', __DIR__ . '/token.json');

// test recipient address (used for filtering)
$testTo = 'zahid.cse02@gmail.com';

function getAccessToken() {
    if (file_exists(TOKEN_FILE)) {
        $token = json_decode(file_get_contents(TOKEN_FILE), true);
        if (time() < $token['created'] + $token['expires_in']) {
            return $token['access_token'];
        } else {
            $response = file_get_contents("https://oauth2.googleapis.com/token", false, stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => "Content-Type: application/x-www-form-urlencoded",
                    'content' => http_build_query([
                        'client_id' => CLIENT_ID,
                        'client_secret' => CLIENT_SECRET,
                        'refresh_token' => $token['refresh_token'],
                        'grant_type' => 'refresh_token'
                    ])
                ]
            ]));
            $newToken = json_decode($response, true);
            if (isset($newToken['access_token'])) {
                $newToken['refresh_token'] = $token['refresh_token'];
                $newToken['created'] = time();
                file_put_contents(TOKEN_FILE, json_encode($newToken));
                return $newToken['access_token'];
            } else {
                echo "<div class='alert alert-danger'>Token refresh failed. Re-authenticate.</div>";
            }
        }
    }

    if (isset($_GET['code'])) {
        $response = file_get_contents("https://oauth2.googleapis.com/token", false, stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded",
                'content' => http_build_query([
                    'code' => $_GET['code'],
                    'client_id' => CLIENT_ID,
                    'client_secret' => CLIENT_SECRET,
                    'redirect_uri' => REDIRECT_URI,
                    'grant_type' => 'authorization_code'
                ])
            ]
        ]));
        $token = json_decode($response, true);
        if (isset($token['access_token'])) {
            $token['created'] = time();
            file_put_contents(TOKEN_FILE, json_encode($token));
            header('Location: ' . REDIRECT_URI);
            exit;
        } else {
            die("Failed to obtain token.");
        }
    } else {
        $auth_url = "https://accounts.google.com/o/oauth2/auth?" . http_build_query([
            'client_id' => CLIENT_ID,
            'redirect_uri' => REDIRECT_URI,
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send',
            'access_type' => 'offline',
            'prompt' => 'consent'
        ]);
        echo "<a class='btn btn-primary' href='$auth_url'>Connect to Gmail</a>";
        exit;
    }
}

function getProfile($access_token) {
    $headers = ["Authorization: Bearer $access_token"];
    $response = file_get_contents("https://gmail.googleapis.com/gmail/v1/users/me/profile", false, stream_context_create([
        'http' => ['method' => 'GET', 'header' => implode("\r\n", $headers)]
    ]));
    return json_decode($response, true);
}

function listMessages($access_token, $label, $filterEmail) {
    $url = "https://gmail.googleapis.com/gmail/v1/users/me/messages?labelIds=$label&maxResults=20";
    $headers = ["Authorization: Bearer $access_token"];
    $result = json_decode(file_get_contents($url, false, stream_context_create([
        'http' => ['method' => 'GET', 'header' => implode("\r\n", $headers)]
    ])), true);

    $messages = [];
    if (isset($result['messages'])) {
        foreach ($result['messages'] as $msg) {
            $id = $msg['id'];
            $msg_url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/$id?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To";
            $message = json_decode(file_get_contents($msg_url, false, stream_context_create([
                'http' => ['method' => 'GET', 'header' => implode("\r\n", $headers)]
            ])), true);

            $headersList = $message['payload']['headers'];
            $subject = $from = $to = '';
            foreach ($headersList as $h) {
                if ($h['name'] === 'Subject') $subject = $h['value'];
                if ($h['name'] === 'From') $from = $h['value'];
                if ($h['name'] === 'To') $to = $h['value'];
            }

            // Only include messages where $filterEmail appears in From or To
            if (stripos($from, $filterEmail) !== false || stripos($to, $filterEmail) !== false) {
                $messages[] = ['subject' => $subject, 'from' => $from];
            }

            // Stop after collecting 5 filtered messages
            if (count($messages) >= 5) {
                break;
            }
        }
    }
    return $messages;
}

function sendMessage($access_token, $to, $subject, $body) {
    $strRawMessage = "To: $to\r\nSubject: $subject\r\n\r\n$body";
    $encodedMessage = rtrim(strtr(base64_encode($strRawMessage), '+/', '-_'), '=');

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Authorization: Bearer $access_token\r\nContent-Type: application/json",
            'content' => json_encode(['raw' => $encodedMessage])
        ]
    ]);

    $response = file_get_contents("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", false, $context);
    if ($response === false) {
        echo "<div class='alert alert-danger'>Email send failed.</div>";
    } else {
        $result = json_decode($response, true);
        echo "<div class='alert alert-success'>Email sent successfully!</div>";
        echo "<pre>Response:\n"; print_r($result); echo "</pre>";
    }
}

$access_token = getAccessToken();
$profile = getProfile($access_token);
$senderEmail = $profile['emailAddress'];

$testSubject = 'Urgent Notification - New Task Assignment for Mr. David';
$testBody = <<<TEXT
Dear Team,

Please be informed that Mr. David has been assigned a new task and is expected to commence work immediately. Kindly notify us as soon as possible to confirm receipt and ensure a smooth start.

Best regards,
TEXT;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email'])) {
    sendMessage($access_token, $_POST['to'], $_POST['subject'], $_POST['message']);
}

$inbox = listMessages($access_token, 'INBOX', $testTo);
$sent = listMessages($access_token, 'SENT', $testTo);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gmail API Client</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
    <h1 class="mb-3">Gmail API Client</h1>
    <div class="alert alert-info">Authenticated as: <strong><?= htmlspecialchars($senderEmail) ?></strong></div>

    <div class="card mb-4">
        <div class="card-header">Send Test Email</div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="send_email" value="1">
                <div class="mb-3"><label>To</label>
                    <input type="email" name="to" class="form-control" value="<?= htmlspecialchars($testTo) ?>" required>
                </div>
                <div class="mb-3"><label>Subject</label>
                    <input type="text" name="subject" class="form-control" value="<?= htmlspecialchars($testSubject) ?>" required>
                </div>
                <div class="mb-3"><label>Message</label>
                    <textarea name="message" class="form-control" rows="7" required><?= htmlspecialchars($testBody) ?></textarea>
                </div>
                <button class="btn btn-primary">Send Email</button>
            </form>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <h3>Inbox (Last 5 for <?= htmlspecialchars($testTo) ?>)</h3>
            <ul class="list-group">
                <?php foreach ($inbox as $msg): ?>
                    <li class="list-group-item"><strong><?= htmlspecialchars($msg['subject']) ?></strong><br><small><?= htmlspecialchars($msg['from']) ?></small></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="col-md-6">
            <h3>Sent (Last 5 for <?= htmlspecialchars($testTo) ?>)</h3>
            <ul class="list-group">
                <?php foreach ($sent as $msg): ?>
                    <li class="list-group-item"><strong><?= htmlspecialchars($msg['subject']) ?></strong><br><small><?= htmlspecialchars($msg['from']) ?></small></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</body>
</html>
