<?php
// Database connection settings
$host = "localhost";
$user = "your_db_user";
$pass = "your_db_password";
$dbname = "your_db_name";

// Connect to MySQL
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
