<?php
include 'dbcon.php';

// Function to get Xero tokens from xero_tokens.json
function getXeroTokens() {
    $file = "xero_tokens.json";

    if (!file_exists($file)) {
        die("Token file not found! Run xero_auth.php first.");
    }

    $json_data = file_get_contents($file);
    $tokens = json_decode($json_data, true);

    if (!isset($tokens['access_token']) || !isset($tokens['tenant_id'])) {
        die("Invalid token data! Run xero_auth.php again.");
    }

    return $tokens;
}

// Read tokens from JSON file
$tokens = getXeroTokens();
$access_token = $tokens['access_token'];
$tenant_id = $tokens['tenant_id'];

// Fetch employee data from database
$sql = "SELECT id, username, username2, dob, email FROM employees";
$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}

// Xero API URL for Employees
$url = "https://api.xero.com/api.xro/2.0/Employees";

while ($row = mysqli_fetch_assoc($result)) {
    $userid = $row['id'];
    $firstname = $row['username'];
    $lastname = $row['username2'];
    $dob = $row['dob'];
    $email = $row['email'];

    $data = [
        "FirstName" => $firstname,
        "LastName" => $lastname,
        "DateOfBirth" => $dob,
        "Email" => $email
    ];

    $json_data = json_encode(["Employees" => [$data]]);

    // Send request to Xero API
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $access_token",
        "Xero-Tenant-Id: $tenant_id",
        "Content-Type: application/json",
        "Accept: application/json"
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo "cURL Error: " . curl_error($ch);
    } else {
        echo "Employee $firstname $lastname synced: $response\n";
    }

    curl_close($ch);
}

// Close database connection
mysqli_close($conn);
?>
