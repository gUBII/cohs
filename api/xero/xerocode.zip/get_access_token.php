<?php

// Xero API credentials
$client_id = "5993E4516A9C4E57B872D21048E00023";
$client_secret = "zzWsAxMzg7nZDg-jIOdIV2nL4sXdb_xNmdmXjMnDcqS7J0O5";
$redirect_uri = "https://nexis365.com/xero/callback.php";
$authorization_code = "v7ka33ZEr835VFkGjEw4J-db_tSBCfbBYoGT8Iz7cJ8"; // Get this from the Xero auth URL

// Xero token endpoint
$url = "https://identity.xero.com/connect/token";

// Request body
$data = http_build_query([
    "grant_type" => "authorization_code",
    "code" => $authorization_code,
    "redirect_uri" => $redirect_uri,
    "client_id" => $client_id,
    "client_secret" => $client_secret
]);

// cURL request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/x-www-form-urlencoded"
]);

$response = curl_exec($ch);
curl_close($ch);

// Decode the response
$response_data = json_decode($response, true);

// Echo the full response for debugging
echo "Full Response:\n";
echo "<pre>" . print_r($response_data, true) . "</pre>";

// Extract the access token
$access_token = isset($response_data['access_token']) ? $response_data['access_token'] : null;

// Save token for later use
file_put_contents("access_token.json", $response);

// Echo access token
if ($access_token) {
    echo "Access token: " . $access_token . "\n";
} else {
    echo "Error: Access token not found.\n";
}

?>
