<?php

if (isset($_GET['code'])) {
    $authorization_code = $_GET['code'];

    // Save authorization code for later use
    file_put_contents("authorization_code.txt", $authorization_code);

    echo "Authorization Code Saved Successfully: " . $authorization_code;
} else {
    echo "Authorization Code Not Found!";
}

?>
