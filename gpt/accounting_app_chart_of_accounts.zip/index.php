<?php include 'includes/header.php'; ?>
<h1>Welcome to Accounting App</h1>
<?php include 'includes/footer.php'; ?>