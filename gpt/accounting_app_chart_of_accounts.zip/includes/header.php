<!DOCTYPE html>
<html><head><title>Accounting App</title><link rel='stylesheet' href='assets/css/style.css'></head><body><nav>Menu</nav>