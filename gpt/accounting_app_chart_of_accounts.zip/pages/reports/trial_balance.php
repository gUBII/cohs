<?php include '../../config/db.php'; ?>
<h2>Trial Balance</h2>