<?php include '../../config/db.php'; ?>
<h2>Income Statement</h2>