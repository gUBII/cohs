<?php include '../../config/db.php'; ?>
<h2>Journal Entries</h2>