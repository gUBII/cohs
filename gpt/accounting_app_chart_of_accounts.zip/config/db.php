<?php
$conn = mysqli_connect('localhost', 'root', '', 'accounting_app');
if (!$conn) die('Connection failed: ' . mysqli_connect_error());
?>