<?php

    echo"<main class='main'>";
        
        include("slider.php");

        include("popular-categories.php");

        include("daily-deals.php");
        
        include("banner-2.php");

        include("flash-sale.php");
                
        include("promotions.php");
        
        include("banner-3.php");

        include("product-latest.php");
    
        // include("special-offers.php");

        include("banner-4.php");
        
        include("featured-brands.php");

        // include("best-selling.php");
        
        // include("blog-front.php");
        
    echo"</main>";

?>
